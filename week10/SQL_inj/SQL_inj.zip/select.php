<?php
include 'library/connect.php';


$name =$_REQUEST['username'];
	$result = mysql_query("SELECT * FROM customers WHERE  username = '$name'");

echo "<table border='1'><tr><th>Firstname</th></tr>";

	while($row = mysql_fetch_array($result))
	{

		echo "<tr>";
		echo "<td>" .$row['username']. "</td>";
	
		echo "</tr>";
	}
echo "</table>";
?>

		<?php
	//}
	include 'library/close.php';
	?>

